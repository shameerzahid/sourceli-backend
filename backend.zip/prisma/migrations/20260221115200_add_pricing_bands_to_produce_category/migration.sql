-- AlterTable
ALTER TABLE "produce_categories" ADD COLUMN "min_price" DOUBLE PRECISION,
ADD COLUMN "max_price" DOUBLE PRECISION;
