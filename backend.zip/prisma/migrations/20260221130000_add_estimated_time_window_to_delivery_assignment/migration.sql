-- AlterTable
ALTER TABLE "delivery_assignments" ADD COLUMN "estimated_time_window" TEXT;
