-- AlterEnum: add PENDING_MODIFICATION to OrderStatus
ALTER TYPE "OrderStatus" ADD VALUE 'PENDING_MODIFICATION';

-- AlterTable: add modification fields to orders
ALTER TABLE "orders" ADD COLUMN "modification_requested_at" TIMESTAMP(3),
ADD COLUMN "modification_message" TEXT;
