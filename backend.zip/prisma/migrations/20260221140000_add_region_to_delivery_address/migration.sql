-- AlterTable
ALTER TABLE "delivery_addresses" ADD COLUMN "region" TEXT;
