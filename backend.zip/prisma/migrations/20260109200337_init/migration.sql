-- CreateEnum
CREATE TYPE "UserRole" AS ENUM ('ADMIN', 'FARMER', 'BUYER');

-- CreateEnum
CREATE TYPE "UserStatus" AS ENUM ('ACTIVE', 'PENDING', 'SUSPENDED', 'BLOCKED', 'APPLIED', 'PROBATIONARY');

-- CreateEnum
CREATE TYPE "BuyerType" AS ENUM ('RESTAURANT', 'HOTEL', 'CATERER', 'INDIVIDUAL');

-- CreateTable
CREATE TABLE "users" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "password_hash" TEXT NOT NULL,
    "role" "UserRole" NOT NULL,
    "status" "UserStatus" NOT NULL DEFAULT 'PENDING',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "farmers" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "full_name" TEXT NOT NULL,
    "farm_name" TEXT,
    "region" TEXT NOT NULL,
    "town" TEXT NOT NULL,
    "weekly_capacity_min" INTEGER NOT NULL,
    "weekly_capacity_max" INTEGER NOT NULL,
    "produce_category" TEXT NOT NULL,
    "feeding_method" TEXT NOT NULL,
    "verification_date" TIMESTAMP(3),
    "verification_admin_id" TEXT,

    CONSTRAINT "farmers_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "buyers" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "full_name" TEXT NOT NULL,
    "business_name" TEXT,
    "buyer_type" "BuyerType" NOT NULL,
    "contact_person" TEXT NOT NULL,
    "estimated_volume" INTEGER,
    "verification_date" TIMESTAMP(3),
    "verification_admin_id" TEXT,

    CONSTRAINT "buyers_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "delivery_addresses" (
    "id" TEXT NOT NULL,
    "buyer_id" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "landmark" TEXT,
    "is_default" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "delivery_addresses_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "farmer_applications" (
    "id" TEXT NOT NULL,
    "farmer_id" TEXT NOT NULL,
    "status" "UserStatus" NOT NULL DEFAULT 'APPLIED',
    "submitted_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "reviewed_at" TIMESTAMP(3),
    "admin_notes" TEXT,
    "rejection_reason" TEXT,

    CONSTRAINT "farmer_applications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "buyer_registrations" (
    "id" TEXT NOT NULL,
    "buyer_id" TEXT NOT NULL,
    "status" "UserStatus" NOT NULL DEFAULT 'PENDING',
    "submitted_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "reviewed_at" TIMESTAMP(3),
    "admin_notes" TEXT,
    "rejection_reason" TEXT,

    CONSTRAINT "buyer_registrations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "farm_photos" (
    "id" TEXT NOT NULL,
    "farmer_id" TEXT NOT NULL,
    "file_path" TEXT NOT NULL,
    "file_type" TEXT NOT NULL,
    "uploaded_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "farm_photos_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "audit_logs" (
    "id" TEXT NOT NULL,
    "user_id" TEXT,
    "action_type" TEXT NOT NULL,
    "entity_type" TEXT NOT NULL,
    "entity_id" TEXT,
    "details" JSONB NOT NULL,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "ip_address" TEXT,

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE UNIQUE INDEX "users_phone_key" ON "users"("phone");

-- CreateIndex
CREATE INDEX "users_email_idx" ON "users"("email");

-- CreateIndex
CREATE INDEX "users_phone_idx" ON "users"("phone");

-- CreateIndex
CREATE INDEX "users_role_idx" ON "users"("role");

-- CreateIndex
CREATE INDEX "users_status_idx" ON "users"("status");

-- CreateIndex
CREATE INDEX "users_role_status_idx" ON "users"("role", "status");

-- CreateIndex
CREATE UNIQUE INDEX "farmers_userId_key" ON "farmers"("userId");

-- CreateIndex
CREATE INDEX "farmers_userId_idx" ON "farmers"("userId");

-- CreateIndex
CREATE INDEX "farmers_region_idx" ON "farmers"("region");

-- CreateIndex
CREATE INDEX "farmers_produce_category_idx" ON "farmers"("produce_category");

-- CreateIndex
CREATE UNIQUE INDEX "buyers_userId_key" ON "buyers"("userId");

-- CreateIndex
CREATE INDEX "buyers_userId_idx" ON "buyers"("userId");

-- CreateIndex
CREATE INDEX "buyers_buyer_type_idx" ON "buyers"("buyer_type");

-- CreateIndex
CREATE INDEX "delivery_addresses_buyer_id_idx" ON "delivery_addresses"("buyer_id");

-- CreateIndex
CREATE INDEX "delivery_addresses_buyer_id_is_default_idx" ON "delivery_addresses"("buyer_id", "is_default");

-- CreateIndex
CREATE UNIQUE INDEX "farmer_applications_farmer_id_key" ON "farmer_applications"("farmer_id");

-- CreateIndex
CREATE INDEX "farmer_applications_status_idx" ON "farmer_applications"("status");

-- CreateIndex
CREATE INDEX "farmer_applications_submitted_at_idx" ON "farmer_applications"("submitted_at");

-- CreateIndex
CREATE UNIQUE INDEX "buyer_registrations_buyer_id_key" ON "buyer_registrations"("buyer_id");

-- CreateIndex
CREATE INDEX "buyer_registrations_status_idx" ON "buyer_registrations"("status");

-- CreateIndex
CREATE INDEX "buyer_registrations_submitted_at_idx" ON "buyer_registrations"("submitted_at");

-- CreateIndex
CREATE INDEX "farm_photos_farmer_id_idx" ON "farm_photos"("farmer_id");

-- CreateIndex
CREATE INDEX "audit_logs_user_id_idx" ON "audit_logs"("user_id");

-- CreateIndex
CREATE INDEX "audit_logs_action_type_idx" ON "audit_logs"("action_type");

-- CreateIndex
CREATE INDEX "audit_logs_entity_type_entity_id_idx" ON "audit_logs"("entity_type", "entity_id");

-- CreateIndex
CREATE INDEX "audit_logs_timestamp_idx" ON "audit_logs"("timestamp");

-- AddForeignKey
ALTER TABLE "farmers" ADD CONSTRAINT "farmers_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "buyers" ADD CONSTRAINT "buyers_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "delivery_addresses" ADD CONSTRAINT "delivery_addresses_buyer_id_fkey" FOREIGN KEY ("buyer_id") REFERENCES "buyers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "farmer_applications" ADD CONSTRAINT "farmer_applications_farmer_id_fkey" FOREIGN KEY ("farmer_id") REFERENCES "farmers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "buyer_registrations" ADD CONSTRAINT "buyer_registrations_buyer_id_fkey" FOREIGN KEY ("buyer_id") REFERENCES "buyers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "farm_photos" ADD CONSTRAINT "farm_photos_farmer_id_fkey" FOREIGN KEY ("farmer_id") REFERENCES "farmers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
